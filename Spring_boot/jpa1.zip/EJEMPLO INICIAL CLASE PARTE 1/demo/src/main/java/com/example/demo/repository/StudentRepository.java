package com.example.demo.repository;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.example.demo.model.Student;

@Repository
public class StudentRepository {
    
    private Map<Integer,Student> data = new HashMap<>();

    public StudentRepository(){
        data.put(1, new Student(1,"Sebastian Angarita","Sistemas",3,"juseanto@javeriana.edu.co"));
        data.put(2, new Student(2,"Margarita Mendoza","Filosofia",2,"margarita@javeriana.edu.co"));
        data.put(3, new Student(3,"Pedro Claver","Matematicas",3,"pedro@javeriana.edu.co"));
        data.put(4, new Student(4,"Camilo Cabra","Sistemas",8,"Camilo@javeriana.edu.co"));
    }

    public Student findById(int id){
        return data.get(id);
    }

    public Collection<Student> findAll(){
        return data.values();
    }

    //nuevos metodos
    public void deleteById(int id){
        data.remove(id);
    }

    public void update(Student student){
        data.put(student.getId(), student);
    }

    public void add(Student student){
        int tam = data.size();
        int lastID = data.get(tam).getId();
        student.setId(lastID+1);
        data.put(lastID+1, student);
    }

}

